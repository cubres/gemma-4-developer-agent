# An imaginary library
Arrange paper cranes by color. No real benchmark task is represented.
